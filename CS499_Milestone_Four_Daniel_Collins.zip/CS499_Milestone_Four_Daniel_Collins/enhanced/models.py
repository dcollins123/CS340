# pydantic models for validating request and response data
# fastapi uses these to check incoming json and generate api docs

from typing import Optional
from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    # login credentials
    username: str = Field(..., min_length=1, max_length=50)
    password: str = Field(..., min_length=1, max_length=128)


class RegisterRequest(BaseModel):
    # new user registration
    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=6, max_length=128)
    role: str = Field(default="read", pattern="^(admin|write|read)$")


class AnimalCreate(BaseModel):
    # fields for creating a new animal record
    animal_id: Optional[str] = None
    animal_type: str = Field(..., min_length=1, max_length=50)
    breed: str = Field(..., min_length=1, max_length=100)
    color: Optional[str] = Field(default=None, max_length=100)
    name: Optional[str] = Field(default=None, max_length=100)
    sex_upon_outcome: Optional[str] = Field(default=None, max_length=50)
    age_upon_outcome_in_weeks: Optional[float] = Field(default=None, ge=0)
    outcome_type: Optional[str] = Field(default=None, max_length=50)
    outcome_subtype: Optional[str] = Field(default=None, max_length=50)
    date_of_birth: Optional[str] = None
    datetime: Optional[str] = None
    monthyear: Optional[str] = None
    location_lat: Optional[float] = None
    location_long: Optional[float] = None


class AnimalUpdate(BaseModel):
    # fields for updating an animal record, all optional
    animal_type: Optional[str] = Field(default=None, max_length=50)
    breed: Optional[str] = Field(default=None, max_length=100)
    color: Optional[str] = Field(default=None, max_length=100)
    name: Optional[str] = Field(default=None, max_length=100)
    sex_upon_outcome: Optional[str] = Field(default=None, max_length=50)
    age_upon_outcome_in_weeks: Optional[float] = Field(default=None, ge=0)
    outcome_type: Optional[str] = Field(default=None, max_length=50)
    outcome_subtype: Optional[str] = Field(default=None, max_length=50)


class TokenResponse(BaseModel):
    # jwt token returned after login
    access_token: str
    token_type: str = "bearer"
    role: str
