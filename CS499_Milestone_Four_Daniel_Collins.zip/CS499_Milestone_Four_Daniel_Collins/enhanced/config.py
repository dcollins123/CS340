# config settings for the animal shelter api
import os

# mongodb connection
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
DB_NAME = "aac"
COLLECTION_NAME = "animals"

# auth settings
SECRET_KEY = os.getenv("SECRET_KEY", "change-this-in-production-use-env-var")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

# bcrypt rounds
BCRYPT_ROUNDS = 12

# whitelist of allowed fields for animal records
ALLOWED_ANIMAL_FIELDS = {
    "animal_id", "animal_type", "breed", "color", "name",
    "sex_upon_outcome", "age_upon_outcome_in_weeks",
    "outcome_type", "outcome_subtype", "date_of_birth",
    "datetime", "monthyear", "location_lat", "location_long",
}
