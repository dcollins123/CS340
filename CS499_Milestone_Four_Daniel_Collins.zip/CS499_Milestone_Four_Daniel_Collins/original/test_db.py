from animal_shelter import AnimalShelter

shelter = AnimalShelter()

results = shelter.read({})

print("Number of records:", len(results))
print("First record:", results[0])
