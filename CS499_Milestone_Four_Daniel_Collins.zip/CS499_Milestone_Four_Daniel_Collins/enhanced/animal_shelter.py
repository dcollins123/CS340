# enhanced crud module for the animal shelter database
# original from cs 340, now with aggregation pipelines, indexing, and input sanitization

from pymongo import MongoClient, ASCENDING
from bson.objectid import ObjectId
from config import MONGO_URI, DB_NAME, COLLECTION_NAME, ALLOWED_ANIMAL_FIELDS


class AnimalShelter:
    # crud operations and analytics for the animals collection

    def __init__(self):
        self.client = MongoClient(MONGO_URI)
        self.database = self.client[DB_NAME]
        self.collection = self.database[COLLECTION_NAME]
        self._ensure_indexes()

    def _ensure_indexes(self):
        # create indexes on fields we query a lot so it doesnt do full collection scans
        self.collection.create_index([("animal_type", ASCENDING)])
        self.collection.create_index([("breed", ASCENDING)])
        self.collection.create_index([("outcome_type", ASCENDING)])
        # compound index for the rescue type filter queries
        self.collection.create_index([
            ("animal_type", ASCENDING),
            ("breed", ASCENDING),
            ("sex_upon_outcome", ASCENDING),
        ])

    # input validation 

    @staticmethod
    def _sanitize_input(data: dict) -> dict:
        # only allow known field names through and block anything starting with $
        # prevents nosql injection
        sanitized = {}
        for key, value in data.items():
            if key not in ALLOWED_ANIMAL_FIELDS:
                continue
            if isinstance(value, str) and value.startswith("$"):
                continue
            sanitized[key] = value
        return sanitized

    # crud operations

    def create(self, data: dict) -> bool:
        # insert one animal record after sanitizing it
        if not data:
            raise ValueError("nothing to save, data is empty")
        clean = self._sanitize_input(data)
        if not clean:
            raise ValueError("no valid fields after sanitization")
        self.collection.insert_one(clean)
        return True

    def read(self, query: dict) -> list:
        # return matching records, accepts raw query dicts with mongo operators
        # the dashboard builds these queries internally so they are safe
        if query is None:
            raise ValueError("query is empty, nothing to read")
        return list(self.collection.find(query, {"_id": 0}))

    def update(self, query: dict, new_data: dict) -> int:
        # update matching records with sanitized data
        if not query or not new_data:
            raise ValueError("need both query and new_data")
        clean = self._sanitize_input(new_data)
        if not clean:
            raise ValueError("no valid fields after sanitization")
        result = self.collection.update_many(query, {"$set": clean})
        return result.modified_count

    def delete(self, query: dict) -> int:
        # delete matching records and return how many were deleted
        if not query:
            raise ValueError("query is empty, nothing to delete")
        result = self.collection.delete_many(query)
        return result.deleted_count

    # aggregation pipelines

    def get_breed_statistics(self, animal_type: str = "Dog") -> list:
        # group by breed, get count and avg age for a given animal type
        pipeline = [
            {"$match": {"animal_type": animal_type}},
            {"$group": {
                "_id": "$breed",
                "count": {"$sum": 1},
                "avg_age_weeks": {"$avg": "$age_upon_outcome_in_weeks"},
            }},
            {"$sort": {"count": -1}},
            {"$limit": 20},
        ]
        return list(self.collection.aggregate(pipeline))

    def get_outcome_trends(self) -> list:
        # group by outcome type and count them
        pipeline = [
            {"$group": {
                "_id": "$outcome_type",
                "count": {"$sum": 1},
            }},
            {"$sort": {"count": -1}},
        ]
        return list(self.collection.aggregate(pipeline))

    def get_age_distribution(self, animal_type: str = "Dog") -> list:
        # bucket animals into age ranges for a histogram
        # 0-26 wks (puppy), 26-52, 52-156, 156-520, 520+
        pipeline = [
            {"$match": {"animal_type": animal_type}},
            {"$bucket": {
                "groupBy": "$age_upon_outcome_in_weeks",
                "boundaries": [0, 26, 52, 156, 520],
                "default": "520+",
                "output": {"count": {"$sum": 1}},
            }},
        ]
        return list(self.collection.aggregate(pipeline))
