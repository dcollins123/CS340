# handles password hashing with bcrypt, jwt tokens, and role-based access
# users stored in a separate mongodb collection with hashed passwords

from datetime import datetime, timedelta, timezone
from typing import Optional

import bcrypt
import jwt
from pymongo import MongoClient

from config import (
    MONGO_URI, DB_NAME, SECRET_KEY, ALGORITHM,
    ACCESS_TOKEN_EXPIRE_MINUTES, BCRYPT_ROUNDS,
)


class AuthManager:
    # manages registration, login, and jwt tokens

    def __init__(self):
        self.client = MongoClient(MONGO_URI)
        self.db = self.client[DB_NAME]
        self.users = self.db["users"]
        self._ensure_admin()

    def _ensure_admin(self):
        # make sure theres at least one admin account for the demo
        if self.users.count_documents({"username": "admin"}) == 0:
            self.register_user("admin", "admin", role="admin")

    # password hashin

    @staticmethod
    def hash_password(password: str) -> str:
        # hash password with bcrypt, salt is generated and embedded automatically
        salt = bcrypt.gensalt(rounds=BCRYPT_ROUNDS)
        return bcrypt.hashpw(password.encode("utf-8"), salt).decode("utf-8")

    @staticmethod
    def verify_password(password: str, hashed: str) -> bool:
        # check plaintext password against stored hash
        return bcrypt.checkpw(
            password.encode("utf-8"),
            hashed.encode("utf-8"),
        )

    # user management

    def register_user(
        self, username: str, password: str, role: str = "read"
    ) -> bool:
        # register new user with hashed password
        # roles: admin (full crud), write (read + create/update), read (read only)
        # defaults to read for least privilege
        if self.users.count_documents({"username": username}) > 0:
            return False
        if role not in ("admin", "write", "read"):
            role = "read"
        self.users.insert_one({
            "username": username,
            "password": self.hash_password(password),
            "role": role,
        })
        return True

    def authenticate_user(self, username: str, password: str) -> Optional[dict]:
        # check credentials and return user info if valid
        user = self.users.find_one({"username": username})
        if user and self.verify_password(password, user["password"]):
            return {"username": user["username"], "role": user["role"]}
        return None

    # jwt tokens

    def create_token(self, username: str, role: str) -> str:
        # generate a signed jwt with username, role, and expiration
        payload = {
            "sub": username,
            "role": role,
            "exp": datetime.now(timezone.utc)
            + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES),
        }
        return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

    def decode_token(self, token: str) -> Optional[dict]:
        # decode jwt and return payload, returns none if expired or invalid
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            return {"username": payload["sub"], "role": payload["role"]}
        except (jwt.ExpiredSignatureError, jwt.InvalidTokenError):
            return None
