from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, port):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        # Connection Variables
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = port
        DB = 'aac'
        COL = 'animals'
        #
        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Method implementing the C in CRUD
    def create(self, data):
        if data is not None:
            self.collection.insert_one(data)  # data should be dictionary
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Method implementing the R in CRUD
    def read(self, query):
        if query is not None:
            return list(self.collection.find(query))
        else:
            raise Exception("Nothing to read, because query parameter is empty")

    # Method implementing the U in CRUD
    def update(self, query, new_data):
        if query is not None and new_data is not None:
            result = self.collection.update_many(query, {'$set': new_data})
            return result.modified_count
        else:
            raise Exception("Nothing to update, because query or new_data parameter is empty")

    # Method implementing the D in CRUD.
    def delete(self, query):
        if query is not None:
            result = self.collection.delete_many(query)
            return result.deleted_count
        else:
            raise Exception("Nothing to delete, because query parameter is empty")
