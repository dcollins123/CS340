from ProjectTwoDashboard import app

app.run(debug=True)
