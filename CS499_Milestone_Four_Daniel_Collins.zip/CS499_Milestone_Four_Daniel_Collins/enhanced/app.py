# fastapi app for the animal shelter dashboard
# enhanced from the cs 340 jupyter/dash version
# now has rest api, jwt auth, rbac, pydantic validation, and aggregation pipelines
# run with: uvicorn app:app --reload --port 8051

from functools import wraps
from typing import Optional

from fastapi import FastAPI, HTTPException, Header, Query
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from animal_shelter import AnimalShelter
from auth import AuthManager
from models import (
    LoginRequest, RegisterRequest, AnimalCreate, AnimalUpdate, TokenResponse,
)

# app setup

app = FastAPI(
    title="Grazioso Salvare Animal Shelter API",
    description="Enhanced CS 340 dashboard with FastAPI, JWT auth, and aggregation pipelines.",
    version="2.0.0",
)

shelter = AnimalShelter()
auth = AuthManager()

# serve the frontend files
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def serve_dashboard():
    # serve the main html page
    return FileResponse("static/index.html")


# ── auth helpers ────────────────────────────────────────────────

def get_current_user(authorization: Optional[str] = Header(None)) -> dict:
    # pull jwt from authorization header and validate it
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid token.")
    token = authorization.split(" ", 1)[1]
    user = auth.decode_token(token)
    if not user:
        raise HTTPException(status_code=401, detail="Token expired or invalid.")
    return user


def require_role(*roles):
    # decorator to restrict endpoints to certain roles
    def decorator(func):
        @wraps(func)
        def wrapper(*args, authorization: Optional[str] = Header(None), **kwargs):
            user = get_current_user(authorization)
            if user["role"] not in roles:
                raise HTTPException(
                    status_code=403,
                    detail=f"Role '{user['role']}' does not have permission.",
                )
            return func(*args, user=user, **kwargs)
        return wrapper
    return decorator


# auth endpoints 

@app.post("/api/login", response_model=TokenResponse)
def login(credentials: LoginRequest):
    # authenticate and return jwt
    user = auth.authenticate_user(credentials.username, credentials.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password.")
    token = auth.create_token(user["username"], user["role"])
    return TokenResponse(access_token=token, role=user["role"])


@app.post("/api/register", status_code=201)
def register(
    payload: RegisterRequest,
    authorization: Optional[str] = Header(None),
):
    # register a new user
    # anyone can make a read-only account, only admins can make write/admin
    if payload.role != "read":
        user = get_current_user(authorization)
        if user["role"] != "admin":
            raise HTTPException(
                status_code=403,
                detail="Only admins can create write/admin accounts.",
            )
    success = auth.register_user(payload.username, payload.password, payload.role)
    if not success:
        raise HTTPException(status_code=409, detail="Username already taken.")
    return {"message": f"User '{payload.username}' registered with role '{payload.role}'."}


# animal crud endpoints

@app.get("/api/animals")
def get_animals(
    authorization: Optional[str] = Header(None),
    animal_type: Optional[str] = Query(None),
    breed: Optional[str] = Query(None),
    rescue_type: Optional[str] = Query(None),
    limit: int = Query(default=100, ge=1, le=1000),
    skip: int = Query(default=0, ge=0),
):
    # read animals with optional filters, requires auth
    # rescue_type maps to the same filter logic as the original dash radio buttons
    user = get_current_user(authorization)
    query = {}

    # rescue type presets (same as original dashboard)
    if rescue_type == "Water":
        query = {
            "animal_type": "Dog",
            "breed": {"$in": [
                "Labrador Retriever Mix",
                "Chesapeake Bay Retriever",
                "Newfoundland",
            ]},
            "sex_upon_outcome": "Intact Female",
            "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
        }
    elif rescue_type == "Mountain":
        query = {
            "animal_type": "Dog",
            "breed": {"$in": [
                "German Shepherd", "Alaskan Malamute",
                "Old English Sheepdog", "Siberian Husky", "Rottweiler",
            ]},
            "sex_upon_outcome": "Intact Male",
            "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
        }
    elif rescue_type == "Disaster":
        query = {
            "animal_type": "Dog",
            "breed": {"$regex": "(Bloodhound|Beagle)", "$options": "i"},
            "age_upon_outcome_in_weeks": {"$lt": 300},
        }
    else:
        # manual filters
        if animal_type:
            query["animal_type"] = animal_type
        if breed:
            query["breed"] = {"$regex": breed, "$options": "i"}

    results = shelter.read(query)
    return {
        "count": len(results),
        "data": results[skip: skip + limit],
    }


@app.post("/api/animals", status_code=201)
def create_animal(
    animal: AnimalCreate,
    authorization: Optional[str] = Header(None),
):
    # create a new animal record, needs write or admin
    user = get_current_user(authorization)
    if user["role"] not in ("write", "admin"):
        raise HTTPException(status_code=403, detail="Write access required.")
    data = animal.model_dump(exclude_none=True)
    shelter.create(data)
    return {"message": "Animal record created."}


@app.put("/api/animals/{animal_id}")
def update_animal(
    animal_id: str,
    updates: AnimalUpdate,
    authorization: Optional[str] = Header(None),
):
    # update animal by animal_id, needs write or admin
    user = get_current_user(authorization)
    if user["role"] not in ("write", "admin"):
        raise HTTPException(status_code=403, detail="Write access required.")
    data = updates.model_dump(exclude_none=True)
    if not data:
        raise HTTPException(status_code=400, detail="No fields to update.")
    count = shelter.update({"animal_id": animal_id}, data)
    return {"modified_count": count}


@app.delete("/api/animals/{animal_id}")
def delete_animal(
    animal_id: str,
    authorization: Optional[str] = Header(None),
):
    # delete animal record, admin only
    user = get_current_user(authorization)
    if user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required.")
    count = shelter.delete({"animal_id": animal_id})
    if count == 0:
        raise HTTPException(status_code=404, detail="No matching record found.")
    return {"deleted_count": count}


# aggregation / analytics endpoints

@app.get("/api/analytics/breeds")
def breed_statistics(
    authorization: Optional[str] = Header(None),
    animal_type: str = Query(default="Dog"),
):
    # top 20 breeds by count with avg age, uses aggregation pipeline
    get_current_user(authorization)
    results = shelter.get_breed_statistics(animal_type)
    return [
        {"breed": r["_id"], "count": r["count"],
         "avg_age_weeks": round(r["avg_age_weeks"], 1)}
        for r in results
    ]


@app.get("/api/analytics/outcomes")
def outcome_trends(authorization: Optional[str] = Header(None)):
    # outcome type distribution, uses aggregation pipeline
    get_current_user(authorization)
    results = shelter.get_outcome_trends()
    return [{"outcome": r["_id"], "count": r["count"]} for r in results]


@app.get("/api/analytics/age-distribution")
def age_distribution(
    authorization: Optional[str] = Header(None),
    animal_type: str = Query(default="Dog"),
):
    # age distribution in bucketed ranges, uses $bucket
    get_current_user(authorization)
    labels = {0: "0-26 wks", 26: "26-52 wks", 52: "1-3 yrs", 156: "3-10 yrs", "520+": "10+ yrs"}
    results = shelter.get_age_distribution(animal_type)
    return [
        {"range": labels.get(r["_id"], str(r["_id"])), "count": r["count"]}
        for r in results
    ]
